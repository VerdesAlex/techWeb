import admin from './admin-router.mjs'
import api from './api-router.mjs'
import auth from './auth-router.mjs'

export default {
  admin,
  api,
  auth
}
