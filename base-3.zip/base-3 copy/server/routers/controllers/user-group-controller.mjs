import models from '../../models/index.mjs'
import { Op } from 'sequelize'

const getAllUserGroups = async (req, res, next) => {
  try {
    const data = await models.UserGroup.findAll()
    res.status(200).json(data)
  } catch (err) {
    next(err)
  }
}

const getOneUserGroup = async (req, res, next) => {
  try {
    const userGroup = await models.UserGroup.findByPk(req.params.ugid)
    if (userGroup) {
      res.status(200).json(userGroup)
    } else {
      res.status(404).json({ message: 'User group not found' })
    }
  } catch (err) {
    next(err)
  }
}

const createUserGroup = async (req, res, next) => {
    try {
        const userGroup  = await models.UserGroup.create(req.body)
        res.status(201).json(userGroup)
    } catch (err) {
        next(err)
    }
}

const updateUserGroup = async (req, res, next) => {
    try {
        const userGroup = await models.UserGroup.findByPk(req.params.tsid)
        if (userGroup) {
            await userGroup.update(req.body)
            res.status(200).json(userGroup)
        } else {
            res.status(404).json({ message: 'Task status not found' })
        }
    } catch (err) {
        next(err)
    }
}

const deleteUserGroup = async (req, res, next) => {
    try {
        const userGroup = await models.UserGroup.findByPk(req.params.tsid)
        if (userGroup) {
            await userGroup.update({ enabled: false })
            res.status(204).end()
        } else {
            res.status(404).json({ message: 'Task status not found' })
        }
    } catch (err) {
        next(err)
    }
}

export default {
  getAllUserGroups,
  getOneUserGroup,
  createUserGroup,
  updateUserGroup,
  deleteUserGroup
}
