import express from 'express'
import middleware from '../middleware/index.mjs'
import controllers from './controllers/index.mjs'

const adminRouter = express.Router()

adminRouter.use(middleware.auth)
adminRouter.use(middleware.getUserTypeMiddleware('admin'))

// user endpoints
adminRouter.get('/users', controllers.user.getUsers)
adminRouter.post('/users', controllers.user.createUser)
adminRouter.put('/users/:uid', controllers.user.updateUser)
adminRouter.delete('/users/:uid', controllers.user.deleteUser)

// task status endpoints
adminRouter.get('/task-statuses', controllers.taskStatus.getAllTaskStatuses)
adminRouter.get('/task-statuses/:tsid', controllers.taskStatus.getOneTaskStatus)
adminRouter.post('/task-statuses', controllers.taskStatus.createTaskStatus)
adminRouter.put('/task-statuses/:tsid', controllers.taskStatus.updateTaskStatus)
adminRouter.delete('/task-statuses/:tsid', controllers.taskStatus.deleteTaskStatus)

// user group endpoints
adminRouter.get('/user-group', controllers.userGroup.getAllUserGroups)
adminRouter.get('/user-group/:ugid', controllers.userGroup.getOneUserGroup)
adminRouter.post('/user-group', controllers.userGroup.createUserGroup)
adminRouter.put('/user-group/:ugid', controllers.userGroup.updateUserGroup)
adminRouter.delete('/user-group/:ugid', controllers.userGroup.deleteUserGroup)

export default adminRouter
