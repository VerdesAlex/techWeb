import './TaskStatusList.css'
import React, { useContext, useEffect, useState } from 'react'
import AppContext from '../../state/AppContext'
import { useNavigate, useParams } from 'react-router-dom'
import TaskStatus from './TaskStatus'
import Paginator from '../Paginator/Paginator'

const TaskStatusList = () => {
  const globalState = useContext(AppContext)
  const [taskStatuses, setTaskStatuses] = useState([])
  const navigate = useNavigate()
  const params = useParams()
  const [pageNumber, setPageNumber] = useState(0)
  const [pageSize, setPageSize] = useState(10)
  const [filterField, setFilterField] = useState('')
  const [filterValue, setFilterValue] = useState('')
  const [sortField, setSortField] = useState('')
  const [sortOrder, setSortOrder] = useState('')

  useEffect(() => {
    globalState.taskStatus.getAll(globalState, pageNumber, pageSize, filterField, filterValue, sortField, sortOrder)
    globalState.taskStatus.emitter.addListener('GET_TASK_STATUSES_SUCCESS', () => {
      setTaskStatuses(globalState.taskStatus.data)
    })
  }, [pageNumber, pageSize, filterField, filterValue, sortField, sortOrder])

  return (
    <div className='task-status-list'>
      <h1>Task status list</h1>
      <table>
        <thead>
          <tr>
            <th>
           		<div>Label</div>
               <input
                type='text' onChange={e => {
                  setFilterValue(e.target.value)
                  setFilterField('label')
                }} placeholder='label filter'
              />
              <button onClick={() => {
                setSortField('label')
                setSortOrder('asc')
              }}
              >⌃
              </button>
              <button onClick={() => {
                setSortField('label')
                setSortOrder('desc')
              }}
              >⌄
              </button>
            </th>
            
            <th>
            	Enabled
            </th>
            <th>
           		<div>Description</div>
               <input
                type='text' onChange={e => {
                  setFilterValue(e.target.value)
                  setFilterField('description')
                }} placeholder='description filter'
              />
              <button onClick={() => {
                setSortField('description')
                setSortOrder('asc')
              }}
              >⌃
              </button>
              <button onClick={() => {
                setSortField('description')
                setSortOrder('desc')
              }}
              >⌄
              </button>
						</th>
            
          </tr>
        </thead>
        <tbody>
          {
            taskStatuses.map(taskStatus => <TaskStatus key={taskStatus.id} taskStatus={taskStatus} />)
          }
        </tbody>
      </table>
      <Paginator
        onPageChange={(pageNumber) => setPageNumber(pageNumber)}
        onPageSizeChange={(pageSize) => setPageSize(pageSize)}
        totalRecords={globalState.taskStatus.count}
      />
      <div className='footer'>
        <button onClick={() => navigate(`/task-statuses/new`)}>
          Create Task Status
        </button>
      </div>
    </div>
  )
}

export default TaskStatusList
