import CommentForm from './CommentForm'

export default CommentForm
