import Comment from './Comment'

export default Comment
