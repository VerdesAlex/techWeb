import CommentList from './CommentList'

export default CommentList
